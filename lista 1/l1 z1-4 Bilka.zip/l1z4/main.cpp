#include <iostream>
#include <limits>

using namespace std;

int main()
{
cout << numeric_limits<double>::epsilon();
}
