#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
int n=1;
    for (int i=1;i<91;i++)
    {
        n*=i;
        cout << n<<endl;
    }

    return 0;
}
