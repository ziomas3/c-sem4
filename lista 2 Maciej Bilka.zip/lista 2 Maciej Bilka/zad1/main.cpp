#include <iostream>

using namespace std;

int main()
{
    int x = 10;
    int * y =&x;
    int ** z=&y;
    double tab[10];
    long long int * tabw[10];
    double * wtab[10];
    char * znak[10];
    char *(*wsk)[10];
    return 0;
}
